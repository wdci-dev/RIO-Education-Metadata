({
    doInit : function(component, event, helper) {
        helper.initCmp(component, event);
    },
}
)