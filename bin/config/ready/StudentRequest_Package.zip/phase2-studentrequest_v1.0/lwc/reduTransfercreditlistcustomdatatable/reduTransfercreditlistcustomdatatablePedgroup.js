/**
 * @description       : 
 * @author            : Pasan (peeriyagama@wdcigroup.net)
 * @group             : 
 * @last modified on  : 24-09-2021
 * @last modified by  : Pasan (peeriyagama@wdcigroup.net) 
 * Modifications Log
 * Ver   Date         Author                              Modification
 * 1.0   24-09-2021   Pasan (peeriyagama@wdcigroup.net)   Initial Version
**/

import { LightningElement } from 'lwc';

export default class ReduTransfercreditlistcustomdatatablePedgroup extends LightningElement {
    
}