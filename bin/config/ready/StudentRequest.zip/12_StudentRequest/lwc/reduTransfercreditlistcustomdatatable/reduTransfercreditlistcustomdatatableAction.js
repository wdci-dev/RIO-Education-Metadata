/**
 * @description       : 
 * @author            : Pasan (peeriyagama@wdcigroup.net)
 * @group             : 
 * @last modified on  : 29-07-2021
 * @last modified by  : Pasan (peeriyagama@wdcigroup.net)
**/
import { LightningElement } from 'lwc';

export default class ReduTransfercreditlistcustomdatatable extends LightningElement {
    
}